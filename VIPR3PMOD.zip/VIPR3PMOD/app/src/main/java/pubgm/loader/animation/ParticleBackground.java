package pubgm.loader.animation;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import androidx.core.content.ContextCompat;
import pubgm.loader.R;

public class ParticleBackground extends View {
    private List<Particle> particles;
    private Paint paint;
    private Random random;
    private int width, height;
    private static final int NUM_PARTICLES = 80;
    private Handler handler;
    private Runnable updateRunnable;

    public ParticleBackground(Context context) {
        super(context);
        init();
    }

    public ParticleBackground(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ParticleBackground(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        particles = new ArrayList<>();
        paint = new Paint();
        random = new Random();
        paint.setAntiAlias(true);
        paint.setColor(Color.WHITE);
        handler = new Handler();
        updateRunnable = new Runnable() {
            @Override
            public void run() {
                updateParticles();
                invalidate();
                handler.postDelayed(this, 16);
            }
        };
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        width = w;
        height = h;

        for (int i = 0; i < NUM_PARTICLES; i++) {
            particles.add(createRandomParticle());
        }

        startAnimation();
    }

    private Particle createRandomParticle() {
        float x = random.nextFloat() * width;
        float y = random.nextFloat() * height;
        float radius = 3.0f + random.nextFloat() * 5.0f;
        float speedX = (random.nextFloat() - 0.5f) * 0.4f;
        float speedY = -(1.0f + random.nextFloat() * 2.0f);
        return new Particle(x, y, radius, speedX, speedY);
    }

    private void updateParticles() {
        for (Particle particle : particles) {
            particle.x += particle.speedX;
            particle.y += particle.speedY;
            if (particle.y + particle.radius < 0) {
                particle.y = height + particle.radius;
                particle.x = random.nextFloat() * width;
            }
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(ContextCompat.getColor(getContext(), R.color.ui2));

        for (Particle particle : particles) {
            float progress = 1.0f - (particle.y / height);
            float alpha = progress * 255;
            paint.setAlpha((int) alpha);
            paint.setShadowLayer(particle.radius / 2, 0, 0, Color.WHITE);
            canvas.drawCircle(particle.x, particle.y, particle.radius, paint);
        }
    }

    public void startAnimation() {
        handler.post(updateRunnable);
    }

    public void stopAnimation() {
        handler.removeCallbacks(updateRunnable);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        startAnimation();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopAnimation();
    }

    private static class Particle {
        float x, y;
        float radius;
        float speedX, speedY;

        Particle(float x, float y, float radius, float speedX, float speedY) {
            this.x = x;
            this.y = y;
            this.radius = radius;
            this.speedX = speedX;
            this.speedY = speedY;
        }
    }
}