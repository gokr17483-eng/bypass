package pubgm.loader.floating;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.os.Looper;
import android.os.Handler;
import android.view.Gravity;
import android.view.ViewConfiguration;
import android.view.WindowManager;

import pubgm.loader.activity.MainActivity;
import pubgm.loader.utils.FLog;
import pubgm.loader.utils.FPrefs;

import java.io.IOException;

public class Overlay extends Service {

    static {
        try {
            System.loadLibrary("livai");
        } catch (UnsatisfiedLinkError w) {
            FLog.error(w.getMessage());
        }
    }

    static Process process;
    private static volatile Overlay Instance = null;

    public FPrefs getPref() {
        return FPrefs.with(this);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private native boolean getReady();
    private native void Close();
    public static native void DrawOn(ESPView espView, Canvas canvas);

    private WindowManager windowManager;
    private ESPView overlayView;
    private final Object addRemoveLock = new Object();
    private volatile boolean isViewAdded = false;

    @SuppressLint("StaticFieldLeak")
    public static Context ctx;

    @SuppressLint("InflateParams")
    @Override
    public void onCreate() {
        super.onCreate();
        ctx = this;
        Instance = this;
        Start();
        windowManager = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        overlayView = new ESPView(ctx);
        DrawCanvas();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            Close();
        } catch (Throwable t) {
            FLog.error(t.getMessage());
        }

        synchronized (addRemoveLock) {
            if (isViewAdded && overlayView != null && windowManager != null) {
                try {
                    windowManager.removeViewImmediate(overlayView);
                } catch (IllegalArgumentException | SecurityException e) {
                    FLog.error(e.getMessage());
                } catch (Throwable t) {
                    FLog.error(t.getMessage());
                } finally {
                    isViewAdded = false;
                    overlayView = null;
                }
            } else {
                overlayView = null;
                isViewAdded = false;
            }
        }
        Instance = null;
        ctx = null;
    }

    private void Start() {
        if (Instance != this) {
            Instance = this;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    getReady();
                } catch (Throwable t) {
                    FLog.error(t.getMessage());
                }
            }
        }, "Overlay-getReady").start();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String cmd = MainActivity.socket;
                    if (cmd != null && !cmd.trim().isEmpty()) {
                        Shell(cmd);
                    }
                } catch (Throwable t) {
                    FLog.error(t.getMessage());
                }
            }
        }, "Overlay-Shell").start();
    }

    private void DrawCanvas() {
        int LAYOUT_FLAG;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
        }

        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                0,
                0,
                LAYOUT_FLAG,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_FULLSCREEN,
                PixelFormat.TRANSLUCENT
        );

        try {
            if (getPref() != null && getPref().readBoolean("anti_recorder")) {
                try {
                    HideRecorder.setFakeRecorderWindowLayoutParams(params);
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 0;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        final WindowManager wm = windowManager;
        final ESPView view = overlayView;
        if (wm == null || view == null) return;

        Handler mainHandler = new Handler(Looper.getMainLooper());
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                synchronized (addRemoveLock) {
                    if (isViewAdded) {
                        try {
                            wm.updateViewLayout(view, params);
                        } catch (Exception e) {
                            FLog.error("Error updating view: " + e.getMessage());
                        }
                        return;
                    }
                    try {
                        wm.addView(view, params);
                        isViewAdded = true;
                        FLog.info("Overlay view added successfully");
                    } catch (Exception e) {
                        FLog.error("Error adding overlay view: " + e.getMessage());
                        tryAlternativeLayout();
                    }
                }
            }
        });
    }

    private void tryAlternativeLayout() {
        try {
            int LAYOUT_FLAG;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            } else {
                LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
            }

            WindowManager.LayoutParams altParams = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    LAYOUT_FLAG,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
            );

            altParams.gravity = Gravity.TOP | Gravity.START;
            windowManager.addView(overlayView, altParams);
            isViewAdded = true;
            FLog.info("Alternative overlay layout applied successfully");
        } catch (Exception e) {
            FLog.error("Alternative layout also failed: " + e.getMessage());
        }
    }

    private int getNavigationBarHeight() {
        try {
            boolean hasMenuKey = ViewConfiguration.get(this).hasPermanentMenuKey();
            int resourceId = getResources().getIdentifier("navigation_bar_height", "dimen", "android");
            if (resourceId > 0 && !hasMenuKey) {
                return getResources().getDimensionPixelSize(resourceId);
            }
        } catch (Throwable t) {
            FLog.error(t.getMessage());
        }
        return 0;
    }

    private void Shell(String str) {
        try {
            if (str == null || str.trim().isEmpty()) {
                return;
            }
            Runtime.getRuntime().exec(str);
        } catch (IOException e) {
            FLog.error(e.getMessage());
        } catch (Throwable t) {
            FLog.error(t.getMessage());
        }
    }

    public static boolean getConfig(String key) {
        try {
            if (ctx == null) return false;
            SharedPreferences sp = ctx.getSharedPreferences("espValue", Context.MODE_PRIVATE);
            return sp.getBoolean(key, false);
        } catch (Throwable t) {
            return false;
        }
    }
}