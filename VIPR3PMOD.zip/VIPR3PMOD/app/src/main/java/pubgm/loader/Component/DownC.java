package pubgm.loader.Component;

import static pubgm.loader.server.ApiServer.activity;
import static pubgm.loader.server.ApiServer.RVm;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;

import net.lingala.zip4j.ZipFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

import pubgm.loader.R;

public class DownC extends AsyncTask<String, Integer, String> {

static {
    System.loadLibrary("livai");
}
    private final Context context;
    private Dialog dialog;
    private TextView percentageText;
    private LottieAnimationView animationView;

    public DownC(Context context) {
        this.context = context;
    }

    @Override
    protected void onPreExecute() {
        // حذف الكاش القديم قبل أي شيء
        clearCache();

        dialog = new Dialog(context, android.R.style.Theme_Translucent_NoTitleBar_Fullscreen);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.animation_downloading);
        dialog.setCancelable(false);

        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT
            );
            window.setBackgroundDrawableResource(android.R.color.transparent);
        }

        animationView = dialog.findViewById(R.id.animation_view);
        percentageText = dialog.findViewById(R.id.percentage_text);

        dialog.show();
    }

    private void clearCache() {
        File cacheDir = context.getCacheDir();
        if (cacheDir != null && cacheDir.isDirectory()) {
            for (File file : cacheDir.listFiles()) {
                file.delete();
            }
        }
    }

    @Override
    protected String doInBackground(String... urls) {
        if (urls == null || urls.length == 0) {
            return "NO_URL";
        }

        try {
            File cacheDir = context.getCacheDir();
            File tempFile = new File(cacheDir, "update_tmp.zip");
            File finalFile = new File(cacheDir, "update.zip");

            URL url = new URL(urls[0]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            String RCV = RVm();
            connection.setRequestProperty("RLA", RCV);
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(15000);
            connection.connect();

            int fileLength = connection.getContentLength();
            InputStream input = connection.getInputStream();
            OutputStream output = new FileOutputStream(tempFile);

            byte[] buffer = new byte[4096];
            long total = 0;
            int count;

            while ((count = input.read(buffer)) != -1) {
                total += count;
                if (fileLength > 0) {
                    publishProgress((int) ((total * 100) / fileLength));
                }
                output.write(buffer, 0, count);
            }

            output.close();
            input.close();

            ZipFile zipCheck = new ZipFile(tempFile);
            if (!zipCheck.isValidZipFile()) {
                tempFile.delete();
                return "INVALID_ZIP";
            }

            if (finalFile.exists()) {
                finalFile.delete();
                solo1("/LIVAI");
            }

            if (!tempFile.renameTo(finalFile)) {
                return "RENAME_FAILED";
            }

            new ZipFile(finalFile).extractAll(context.getFilesDir().getPath());
            return "SUCCESS";

        } catch (Exception e) {
            return "ERROR";
        }
    }

    public void solo1(String path) {
        try {
            ExecuteElf("chmod 777 " + context.getFilesDir() + path);
            ExecuteElf("su -c chmod 777 " + context.getFilesDir() + path);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void ExecuteElf(String command) {
        try {
            Runtime.getRuntime().exec(command);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        if (values.length > 0) {
            percentageText.setText(values[0] + "%");
            animationView.setProgress(values[0] / 100f);
        }
    }

    @Override
    protected void onPostExecute(String result) {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }

if ("SUCCESS".equals(result)) {
    try {
        Class<?> cls = Class.forName(activity());
        Intent intent = new Intent(context.getApplicationContext(), cls);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);
    } catch (Exception e) {
        Toast.makeText(context, "رستر التطبيق", Toast.LENGTH_LONG).show();
    }
} else {
    Toast.makeText(context, "رستر التطبيق", Toast.LENGTH_LONG).show();
}
    }
}