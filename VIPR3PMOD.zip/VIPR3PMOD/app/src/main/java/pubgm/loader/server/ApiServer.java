package pubgm.loader.server;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

public class ApiServer {

    private static boolean libraryLoaded = false;

    static {
        try {
            System.loadLibrary("livai");
            libraryLoaded = true;
        } catch (UnsatisfiedLinkError ignored) {
            libraryLoaded = false;
        }
    }

    public static native String mainURL();
    public static native String activity();
    public static native String crashfix();
    public static native String RVm();
    public static native String EXP();
    public static native String ApiKeyBox();
    public static native String getOwner();
    public static native String LINKspkvi();
    public static native String Warnings();
    public static native String ByPass();
    public static native String LINKserver(Context mContext, String userKey, String gameType);
    public static native String getGameTypeVIP();
    public static native String getGameTypeFREE();

    private static native void verifySignatureNative(Activity activity);
    private static native boolean nativeVerifyAppLabel(String appLabel);

    public static void verify(Activity activity) {
        if (activity == null) {
            throw new RuntimeException("Activity is null");
        }
        verifySignatureNative(activity);
    }

    public static boolean verifyAppLabel(Activity activity) {
        if (!libraryLoaded) {
            return true;
        }

        try {
            ApplicationInfo appInfo = activity.getPackageManager()
                    .getApplicationInfo(activity.getPackageName(), 0);

            String appLabel = (String) activity.getPackageManager()
                    .getApplicationLabel(appInfo);

            return nativeVerifyAppLabel(appLabel);

        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (UnsatisfiedLinkError e) {
            e.printStackTrace();
            return true;
        }
    }
}