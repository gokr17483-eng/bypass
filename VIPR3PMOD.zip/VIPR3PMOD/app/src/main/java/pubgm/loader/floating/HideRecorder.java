package pubgm.loader.floating;

import android.annotation.SuppressLint;
import android.os.Build;
import android.text.TextUtils;
import android.view.WindowManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class HideRecorder {

    public static final String ROM_UNKNOWN = "UNKNOWN";
    private static String sName;

    public static boolean isActivice() {
        return false;
    }

    @SuppressLint({"PrivateApi", "DiscouragedPrivateApi"})
    public static void setFakeRecorderWindowLayoutParams(WindowManager.LayoutParams layoutParams) {
        try {
            String fakeTitle = getFakeRecordWindowTitle();
            if (!TextUtils.isEmpty(fakeTitle)) {
                layoutParams.setTitle(fakeTitle);
            }

            setUniversalCompatibleParams(layoutParams);
            setUniversalFlags(layoutParams);
            setHiddenFromRecordingAndScreenshot(layoutParams);
            
        } catch (Exception e) {
            e.printStackTrace();
            setHiddenFromRecordingAndScreenshot(layoutParams);
        }
    }

    private static void setUniversalCompatibleParams(WindowManager.LayoutParams params) {
        try {
            params.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            params.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
            params.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
            params.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR;
            params.flags |= WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
            params.flags |= WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                params.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            } else {
                params.type = WindowManager.LayoutParams.TYPE_PHONE;
            }
            
            params.format = android.graphics.PixelFormat.TRANSLUCENT;
            params.alpha = 1.0f;
            params.flags &= ~WindowManager.LayoutParams.FLAG_SECURE;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void setUniversalFlags(WindowManager.LayoutParams params) {
        try {
            params.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            params.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
            params.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
            params.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR;
            params.flags |= WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
            params.flags |= WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
            
            try {
                Field extraFlagsField = params.getClass().getDeclaredField("extraFlags");
                extraFlagsField.setAccessible(true);
                int extraFlags = extraFlagsField.getInt(params);
                extraFlags |= 0x00000040;
                extraFlagsField.setInt(params, extraFlags);
            } catch (Exception e) {
            }
            
            try {
                Field privateFlagField = params.getClass().getDeclaredField("privateFlags");
                privateFlagField.setAccessible(true);
                int privateFlags = privateFlagField.getInt(params);
                privateFlags |= 0x00000040;
                privateFlagField.setInt(params, privateFlags);
            } catch (Exception e) {
            }
            
            try {
                Method semAddExtensionFlags = params.getClass().getMethod("semAddExtensionFlags", int.class);
                semAddExtensionFlags.invoke(params, -2147352576);
            } catch (Exception e) {
            }
            
            try {
                Method semAddPrivateFlags = params.getClass().getMethod("semAddPrivateFlags", int.class);
                semAddPrivateFlags.invoke(params, params.flags);
            } catch (Exception e) {
            }
            
            try {
                Field mzParamsField = params.getClass().getDeclaredField("meizuFlags");
                mzParamsField.setAccessible(true);
                mzParamsField.setInt(params, 1024);
            } catch (Exception e) {
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void setHiddenFromRecordingAndScreenshot(WindowManager.LayoutParams params) {
        try {
            params.flags &= ~WindowManager.LayoutParams.FLAG_SECURE;
            params.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            params.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
            params.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
            params.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR;
            params.flags |= WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                params.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            } else {
                params.type = WindowManager.LayoutParams.TYPE_PHONE;
            }
            
            params.format = android.graphics.PixelFormat.TRANSLUCENT;
            params.alpha = 1.0f;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String getFakeRecordWindowTitle() {
        return "SystemUI";
    }

    private static boolean check(String rom) {
        return true;
    }

    private static String detectRom() {
        return ROM_UNKNOWN;
    }

    private static String getProp(String name) {
        String line = null;
        BufferedReader input = null;
        try {
            Process p = Runtime.getRuntime().exec("getprop " + name);
            input = new BufferedReader(new InputStreamReader(p.getInputStream()), 1024);
            line = input.readLine();
            input.close();
        } catch (IOException ex) {
            return null;
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return line;
    }

    public static String getDetectedRomName() {
        return ROM_UNKNOWN;
    }
}