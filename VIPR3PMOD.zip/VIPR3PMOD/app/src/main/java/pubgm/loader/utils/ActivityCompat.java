package pubgm.loader.utils;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import com.blankj.molihuan.utilcode.util.ToastUtils;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.switchmaterial.SwitchMaterial;

import org.jdeferred.android.AndroidDeferredManager;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import pubgm.loader.BuildConfig;
import pubgm.loader.R;
import pubgm.loader.activity.CrashHandler;
import pubgm.loader.activity.MainActivity;

public class ActivityCompat extends AppCompatActivity {

    @Override
    protected void attachBaseContext(Context newBase) {
        myTools m = new myTools(newBase);
        String savedLang = m.getSt("myLang", "mapLang", "auto");

        Context context;
        if ("auto".equals(savedLang)) {
            context = updateLocale(newBase, Locale.getDefault().getLanguage());
        } else {
            context = updateLocale(newBase, savedLang);
        }
        super.attachBaseContext(context);
    }

    private Context updateLocale(Context context, String langCode) {
        Locale locale = new Locale(langCode);
        Locale.setDefault(locale);

        Configuration config = new Configuration(context.getResources().getConfiguration());
        config.setLocale(locale);

        return context.createConfigurationContext(config);
    }

    private static ActivityCompat activityCompat;
    public static int REQUEST_OVERLAY_PERMISSION = 5469;
    public static int PERMISSION_REQUEST_STORAGE = 100;
    public static int REQUEST_MANAGE_UNKNOWN_APP_SOURCES = 200;
    public static int REQUEST_BODY_SENSORS_PERMISSION = 300;
    public static int REQUEST_MEDIA_PERMISSION = 400;
    public boolean isLogin = false;
    public FPrefs prefs;
    private BottomSheetDialog bottomSheetDialog;
    public static String gamename;
    public static String name;
    public static int version;
    public static String url;
    private static ExecutorService executorService = Executors.newSingleThreadExecutor();

    private SwitchMaterial switchOverlay, switchInstall, switchFiles, switchBodySensors, switchMedia;
    private MaterialButton btnContinue;
    private LinearLayout permissionRoot;

    public static ActivityCompat getActivityCompat() {
        return activityCompat;
    }

    protected static void requestPermissions(MainActivity mainActivity, String[] strings, int requestPermissions) {
    }

    public FPrefs getPref() {
        return FPrefs.with(this);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        activityCompat = this;
        super.onCreate(savedInstanceState);
        Thread.setDefaultUncaughtExceptionHandler(new CrashHandler(this));
        setNavBar(R.color.ui);
        prefs = getPref();
        checkAllPermissions();
    }

    public void setNavBar(int color) {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        getWindow().setStatusBarColor(ContextCompat.getColor(this, color));
    }

    public void restartApp(String clazz) {
        Intent lauchIntent = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (lauchIntent != null) {
            lauchIntent.addFlags(335577088);
            lauchIntent.putExtra("restartApp", clazz);
            startActivity(lauchIntent);
            Runtime.getRuntime().exit(0);
        } else {
            Intent fallbackIntent = new Intent(this, MainActivity.class);
            fallbackIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(fallbackIntent);
            Runtime.getRuntime().exit(0);
        }
    }

    public void toast(CharSequence msg) {
        ToastUtils _toast = ToastUtils.make();
        _toast.setBgColor(android.R.color.white);
        _toast.setLeftIcon(R.drawable.icon);
        _toast.setTextColor(android.R.color.black);
        _toast.setNotUseSystemToast();
        _toast.show(msg);
    }

    public void showRgbToast(String message) {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast, (ViewGroup) findViewById(R.id.custom_toast_container));

        ImageView icon = layout.findViewById(R.id.toast_icon);
        icon.setImageResource(R.drawable.icon);

        TextView text = layout.findViewById(R.id.toast_text);
        text.setText(message);

        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.BOTTOM, 0, 100);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(layout);
        toast.show();
    }

    public void showPremiumRgbToast(String message) {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast, (ViewGroup) findViewById(R.id.custom_toast_container));

        ImageView icon = layout.findViewById(R.id.toast_icon);
        icon.setImageResource(R.drawable.icon);

        TextView text = layout.findViewById(R.id.toast_text);
        text.setText(message);

        LinearLayout toastLayout = layout.findViewById(R.id.toast_card);

        startRgbEffect(toastLayout, text);

        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.BOTTOM, 0, 100);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(layout);
        toast.show();
    }
private void startRgbEffect(LinearLayout linearLayout, TextView textView) {
    final int[] borderColors = {
        0xFFFF0000,
        0xFF00FF00, 
        0xFF0000FF,
        0xFFFFFF00,
        0xFFFF00FF,
        0xFF00FFFF
    };

    final int[] textColors = {
        0xFFFF0000,
        0xFF00FF00,
        0xFF0000FF, 
        0xFFFFFF00,
        0xFFFF00FF,
        0xFF00FFFF
    };

    android.animation.ValueAnimator colorAnimation = android.animation.ValueAnimator.ofInt(0, borderColors.length - 1);
    colorAnimation.setDuration(3000);
    colorAnimation.setRepeatCount(0);
    colorAnimation.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
        @Override
        public void onAnimationUpdate(android.animation.ValueAnimator animator) {
            int index = (Integer) animator.getAnimatedValue();
            
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setColor(0xFF2C2C2C);
            gradientDrawable.setStroke(2, borderColors[index]);
            gradientDrawable.setCornerRadius(25);
            
            linearLayout.setBackground(gradientDrawable);
            textView.setTextColor(textColors[index]);
        }
    });
    colorAnimation.start();
}

    public static void toastImage(int id, String msg) {
        ToastUtils _toast = ToastUtils.make();
        _toast.setBgColor(android.R.color.white);
        _toast.setLeftIcon(id);
        _toast.setTextColor(android.R.color.black);
        _toast.setNotUseSystemToast();
        _toast.show(msg);
    }

    public void RestartAppp() {
        PackageManager pm = getPackageManager();
        Intent intent = pm.getLaunchIntentForPackage(getPackageName());
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        } else {
            Intent fallbackIntent = new Intent(this, MainActivity.class);
            fallbackIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(fallbackIntent);
        }
        finish();
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(0);
    }

    public void ShowRestartApp() {
        showBottomSheetDialog(
                getResources().getDrawable(R.drawable.ic_check),
                "Download Success: Restart Loader",
                "The loader has been downloaded successfully. Please restart the loader now.",
                false,
                v -> {
                    MainActivity.get().doShowProgress(true);
                    RestartAppp();
                    dismissBottomSheetDialog();
                },
                null);
    }

    public void checkAllPermissions() {
        if (isStoragePermissionGranted() && isOverlayPermissionGranted() && isInstallPermissionGranted() && isBodySensorsPermissionGranted() && isMediaPermissionGranted()) {
            return;
        } else {
            showPermissionsBottomSheet();
        }
    }

    private boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return Environment.isExternalStorageManager();
        } else {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
    }

    private boolean isOverlayPermissionGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return Settings.canDrawOverlays(this);
        }
        return true;
    }

    private boolean isInstallPermissionGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return getPackageManager().canRequestPackageInstalls();
        }
        return true;
    }

    private boolean isBodySensorsPermissionGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.BODY_SENSORS) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private boolean isMediaPermissionGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED &&
                   ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED &&
                   ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED;
        } else {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                   ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
    }

    public void showPermissionsBottomSheet() {
        if (BuildConfig.VERSION_CODE == 200) {
            return;
        }

        bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setCancelable(false);
        bottomSheetDialog.setContentView(R.layout.permissions_bottom_sheet);

        switchOverlay = bottomSheetDialog.findViewById(R.id.switch_overlay);
        switchInstall = bottomSheetDialog.findViewById(R.id.switch_install);
        switchFiles = bottomSheetDialog.findViewById(R.id.switch_files);
        switchBodySensors = bottomSheetDialog.findViewById(R.id.switch_body_sensors);
        switchMedia = bottomSheetDialog.findViewById(R.id.switch_media);
        btnContinue = bottomSheetDialog.findViewById(R.id.btn_continue);
        permissionRoot = bottomSheetDialog.findViewById(R.id.permission_root);

        updateSwitchesState();

        switchOverlay.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked && !isOverlayPermissionGranted()) {
                requestOverlayPermission();
            } else if (isChecked) {
                showRgbToast("تم منح إذن الظهور فوق التطبيقات بنجاح");
            }
        });

        switchInstall.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked && !isInstallPermissionGranted()) {
                requestInstallPermission();
            } else if (isChecked) {
                showRgbToast("تم منح إذن تثبيت تطبيقات غير معروفة بنجاح");
            }
        });

        switchFiles.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked && !isStoragePermissionGranted()) {
                requestStoragePermission();
            } else if (isChecked) {
                showRgbToast("تم منح إذن الوصول إلى الملفات بنجاح");
            }
        });

        switchBodySensors.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked && !isBodySensorsPermissionGranted()) {
                requestBodySensorsPermission();
            } else if (isChecked) {
                showRgbToast("تم منح إذن استشعار الأجسام بنجاح");
            }
        });

        switchMedia.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked && !isMediaPermissionGranted()) {
                requestMediaPermission();
            } else if (isChecked) {
                showRgbToast("تم منح إذن الوصول إلى الوسائط بنجاح");
            }
        });

        btnContinue.setOnClickListener(v -> {
            if (isStoragePermissionGranted() && isOverlayPermissionGranted() && isInstallPermissionGranted() && isBodySensorsPermissionGranted() && isMediaPermissionGranted()) {
                showPremiumRgbToast("تم منح جميع الأذونات بنجاح");
                new android.os.Handler().postDelayed(() -> {
                    dismissBottomSheetDialog();
                }, 3000);
            } else {
                toast("يرجى منح جميع الأذونات أولاً");
            }
        });

        updateContinueButton();

        bottomSheetDialog.show();
    }

    private void updateSwitchesState() {
        if (switchOverlay != null) {
            switchOverlay.setChecked(isOverlayPermissionGranted());
        }
        if (switchInstall != null) {
            switchInstall.setChecked(isInstallPermissionGranted());
        }
        if (switchFiles != null) {
            switchFiles.setChecked(isStoragePermissionGranted());
        }
        if (switchBodySensors != null) {
            switchBodySensors.setChecked(isBodySensorsPermissionGranted());
        }
        if (switchMedia != null) {
            switchMedia.setChecked(isMediaPermissionGranted());
        }
    }

    private void updateContinueButton() {
        if (btnContinue != null) {
            if (isStoragePermissionGranted() && isOverlayPermissionGranted() && isInstallPermissionGranted() && isBodySensorsPermissionGranted() && isMediaPermissionGranted()) {
                btnContinue.setVisibility(View.VISIBLE);
                btnContinue.setEnabled(true);
                btnContinue.setAlpha(1.0f);
            } else {
                btnContinue.setVisibility(View.GONE);
                btnContinue.setEnabled(false);
                btnContinue.setAlpha(0.5f);
            }
        }
    }

    public void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            Uri uri = Uri.fromParts("package", getPackageName(), null);
            intent.setData(uri);
            startActivityForResult(intent, PERMISSION_REQUEST_STORAGE);
        } else {
            androidx.core.app.ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.MANAGE_EXTERNAL_STORAGE
                    },
                    PERMISSION_REQUEST_STORAGE);
        }
    }

    public void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            Uri uri = Uri.fromParts("package", getPackageName(), null);
            intent.setData(uri);
            startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
        }
    }

    public void requestInstallPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
            Uri uri = Uri.fromParts("package", getPackageName(), null);
            intent.setData(uri);
            startActivityForResult(intent, REQUEST_MANAGE_UNKNOWN_APP_SOURCES);
        }
    }

    public void requestBodySensorsPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
            androidx.core.app.ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.BODY_SENSORS},
                    REQUEST_BODY_SENSORS_PERMISSION);
        }
    }

    public void requestMediaPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            androidx.core.app.ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.READ_MEDIA_IMAGES,
                            Manifest.permission.READ_MEDIA_VIDEO,
                            Manifest.permission.READ_MEDIA_AUDIO
                    },
                    REQUEST_MEDIA_PERMISSION);
        } else {
            androidx.core.app.ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                    },
                    REQUEST_MEDIA_PERMISSION);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (bottomSheetDialog != null && bottomSheetDialog.isShowing()) {
            updateSwitchesState();
            updateContinueButton();
            
            if (requestCode == REQUEST_OVERLAY_PERMISSION && isOverlayPermissionGranted()) {
                showRgbToast("تم منح إذن الظهور فوق التطبيقات بنجاح");
            } else if (requestCode == REQUEST_MANAGE_UNKNOWN_APP_SOURCES && isInstallPermissionGranted()) {
                showRgbToast("تم منح إذن تثبيت تطبيقات غير معروفة بنجاح");
            } else if (requestCode == PERMISSION_REQUEST_STORAGE && isStoragePermissionGranted()) {
                showRgbToast("تم منح إذن الوصول إلى الملفات بنجاح");
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (bottomSheetDialog != null && bottomSheetDialog.isShowing()) {
            updateSwitchesState();
            updateContinueButton();
            
            if (requestCode == PERMISSION_REQUEST_STORAGE && isStoragePermissionGranted()) {
                showRgbToast("تم منح إذن الوصول إلى الملفات بنجاح");
            } else if (requestCode == REQUEST_BODY_SENSORS_PERMISSION && isBodySensorsPermissionGranted()) {
                showRgbToast("تم منح إذن استشعار الأجسام بنجاح");
            } else if (requestCode == REQUEST_MEDIA_PERMISSION && isMediaPermissionGranted()) {
                showRgbToast("تم منح إذن الوصول إلى الوسائط بنجاح");
            }
        }
    }

    public void takeFilePermissions() {
        requestStoragePermission();
    }

    public void InstllUnknownApp() {
        requestInstallPermission();
    }

    public void OverlayPermision() {
        requestOverlayPermission();
    }

    public void BodySensorsPermission() {
        requestBodySensorsPermission();
    }

    public void MediaPermission() {
        requestMediaPermission();
    }

    public void ManageFiles() {
        checkAllPermissions();
    }

    protected AndroidDeferredManager defer() {
        return UiKit.defer();
    }

    private long backPressedTime = 0;

    @Override
    public void onBackPressed() {
        if (isLogin) {
            long t = System.currentTimeMillis();
            if (t - backPressedTime > 2000) {
                backPressedTime = t;
                toast("Press back again to exit");
            } else {
                super.onBackPressed();
            }
        }
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    private void showSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    public void launch(AlertDialog dialog, String pkg) {
        UiKit.defer().when(() -> {
            long startTime = System.currentTimeMillis();
            dialog.dismiss();
            long elapsedTime = System.currentTimeMillis() - startTime;
            long delta = 500L - elapsedTime;
            if (delta > 0) {
                UiKit.sleep(delta);
            }
        }).done((ree) -> {
        });
    }

    public void launchSplash(String pkg) {
        try {
            View view = getLayoutInflater().inflate(R.layout.launcher, null);
            CardView cv = view.findViewById(R.id.cv_lauch);
            TextView txt = view.findViewById(R.id.start_livai);

            MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
            builder.setCancelable(false)
                    .setView(view)
                    .setBackground(this.getResources().getDrawable(R.drawable.background_trans));

            AlertDialog dialog = builder.create();
            dialog.show();

            defer().when(() -> {
                long startTime = System.currentTimeMillis();
                long elapsedTime = System.currentTimeMillis() - startTime;
                long delta = 5000L - elapsedTime;
                if (delta > 0) {
                    UiKit.sleep(delta);
                }
            }).done((ree) -> launch(dialog, pkg)).fail(fa -> dialog.dismiss());

        } catch (Exception err) {
            FLog.error(err.getCause().getMessage());
        }
    }

    public void showBottomSheetDialogUninstall(Drawable icon, String title, String msg, boolean cancelable, View.OnClickListener confirmListener) {
        if (BuildConfig.VERSION_CODE == 200) {
            return;
        }
        bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setCancelable(cancelable);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_dialog_layout);

        ImageView img = bottomSheetDialog.findViewById(R.id.icon);
        if (icon != null) {
            img.setImageDrawable(icon);
        }
        TextView title_tv = bottomSheetDialog.findViewById(R.id.title);
        title_tv.setText(title);
        TextView msg_tv = bottomSheetDialog.findViewById(R.id.msg);
        msg_tv.setText(msg);
        MaterialButton confirm = bottomSheetDialog.findViewById(R.id.btn);
        if (confirmListener != null) {
            confirm.setOnClickListener(confirmListener);
        }

        MaterialButton cancel = bottomSheetDialog.findViewById(R.id.btn_cancle);
        cancel.setOnClickListener(v -> bottomSheetDialog.dismiss());

        bottomSheetDialog.show();
    }

    public void showBottomSheetDialog(Drawable icon, String title, String msg, boolean cancelable, View.OnClickListener listener, View.OnClickListener listenerCancle) {
        if (BuildConfig.VERSION_CODE == 200) {
            return;
        }
        bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setCancelable(cancelable);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_dialog_layout);

        ImageView img = bottomSheetDialog.findViewById(R.id.icon);
        if (icon != null) {
            img.setImageDrawable(icon);
        }
        TextView title_tv = bottomSheetDialog.findViewById(R.id.title);
        title_tv.setText(title);
        TextView msg_tv = bottomSheetDialog.findViewById(R.id.msg);
        msg_tv.setText(msg);

        MaterialButton download = bottomSheetDialog.findViewById(R.id.btn);
        if (listener != null) {
            download.setOnClickListener(listener);
        }

        MaterialButton cancle = bottomSheetDialog.findViewById(R.id.btn_cancle);
        if (listenerCancle != null) {
            cancle.setOnClickListener(listenerCancle);
        } else {
            cancle.setVisibility(View.GONE);
        }

        bottomSheetDialog.show();
    }

    public void showBottomSheetDialog2(Drawable icon, String title, String msg, boolean cancelable, View.OnClickListener listener, View.OnClickListener updates, View.OnClickListener listenerCancle) {
        if (BuildConfig.VERSION_CODE == 200) {
            return;
        }
        bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setCancelable(cancelable);
        bottomSheetDialog.setContentView(R.layout.bottom_update);

        ImageView img = bottomSheetDialog.findViewById(R.id.icon);
        if (icon != null) {
            img.setImageDrawable(icon);
        }
        TextView title_tv = bottomSheetDialog.findViewById(R.id.title);
        title_tv.setText(title);
        TextView msg_tv = bottomSheetDialog.findViewById(R.id.msg);
        msg_tv.setText(msg);

        MaterialButton download = bottomSheetDialog.findViewById(R.id.btn);
        if (listener != null) {
            download.setOnClickListener(listener);
        }

        MaterialButton updatess = bottomSheetDialog.findViewById(R.id.updateee);
        if (updates != null) {
            updatess.setOnClickListener(updates);
        }

        MaterialButton cancle = bottomSheetDialog.findViewById(R.id.btn_cancle);
        if (listenerCancle != null) {
            cancle.setOnClickListener(listenerCancle);
        } else {
            cancle.setVisibility(View.GONE);
        }

        bottomSheetDialog.show();
    }

    public void showBottomSheetDialog3(Drawable icon, String title, String msg, boolean cancelable, View.OnClickListener listener, View.OnClickListener updates, View.OnClickListener listenerCancle) {
        if (BuildConfig.VERSION_CODE == 200) {
            return;
        }
        bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setCancelable(cancelable);
        bottomSheetDialog.setContentView(R.layout.bottom_logout);

        ImageView img = bottomSheetDialog.findViewById(R.id.icon);
        if (icon != null) {
            img.setImageDrawable(icon);
        }
        TextView title_tv = bottomSheetDialog.findViewById(R.id.title);
        title_tv.setText(title);
        TextView msg_tv = bottomSheetDialog.findViewById(R.id.msg);
        msg_tv.setText(msg);

        MaterialButton updatess = bottomSheetDialog.findViewById(R.id.updateee);
        if (updates != null) {
            updatess.setOnClickListener(updates);
        }

        MaterialButton cancle = bottomSheetDialog.findViewById(R.id.btn_cancle);
        if (listenerCancle != null) {
            cancle.setOnClickListener(listenerCancle);
        } else {
            cancle.setVisibility(View.GONE);
        }

        bottomSheetDialog.show();
    }

    public void dismissBottomSheetDialog() {
        try {
            if (bottomSheetDialog != null && bottomSheetDialog.isShowing()) {
                bottomSheetDialog.dismiss();
                bottomSheetDialog = null;
            }
        } catch (Exception err) {
            FLog.error(err.getMessage());
        }
    }
}