package pubgm.loader.activity;

import static pubgm.loader.server.ApiServer.mainURL;

import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.button.MaterialButton;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import io.michaelrocks.paranoid.Obfuscate;
import pubgm.loader.Component.DownC;
import pubgm.loader.Component.Prefs;
import pubgm.loader.R;
import pubgm.loader.utils.ActivityCompat;
import pubgm.loader.utils.FLog;

@Obfuscate
public class LoginActivity extends ActivityCompat {

    static {
        try {
            System.loadLibrary("livai");
        } catch (UnsatisfiedLinkError e) {
            FLog.error(e.getMessage());
        }
    }

    private static final String USER = "USER";
    public static String USERKEY;

    private Prefs prefs;
    private LottieAnimationView lottieView;
    private ImageView placeholderBg;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean isLogging = new AtomicBoolean(false);

    private AlertDialog loadingDialog;
    private MaterialButton btnSignIn;
    private TextView textUsername;
    private TextView errorUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        getWindow().setBackgroundDrawable(null);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);

        setContentView(R.layout.activity_login);

        lottieView = findViewById(R.id.lottie_view);
        placeholderBg = findViewById(R.id.placeholder_bg);

        if (lottieView != null) {
            lottieView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            lottieView.setAlpha(1f);
        }
        if (placeholderBg != null) {
            placeholderBg.setVisibility(View.GONE);
        }

        initDesign();
    }

    private void initDesign() {
        prefs = Prefs.with(this);

        textUsername = findViewById(R.id.textUsername);
        errorUsername = findViewById(R.id.error_username);
        btnSignIn = findViewById(R.id.loginBtn);
        ImageView pasteIcon = findViewById(R.id.paste_icon);

        textUsername.setText(prefs.read(USER, ""));

        btnSignIn.setOnClickListener(v -> {
            if (isLogging.get()) return;

            String key = textUsername.getText().toString().trim();
            if (key.isEmpty()) {
                errorUsername.setVisibility(View.VISIBLE);
                return;
            }

            errorUsername.setVisibility(View.GONE);
            prefs.write(USER, key);
            USERKEY = key;
            startLogin();
        });

        if (pasteIcon != null) {
            pasteIcon.setOnClickListener(v -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null && cm.getText() != null) {
                    textUsername.setText(cm.getText().toString());
                }
            });
        }
    }

    private void startLogin() {
        if (!isLogging.compareAndSet(false, true)) return;

        btnSignIn.setEnabled(false);
        showLoading();

        executor.execute(() -> {
            String res = native_Check(this, USERKEY);
            mainHandler.post(() -> {
                hideLoading();
                isLogging.set(false);
                btnSignIn.setEnabled(true);

                if ("OK".equals(res)) {
                    Toast.makeText(this, "Login Success", Toast.LENGTH_SHORT).show();
                    new DownC(this).execute(mainURL());
                } else {
                    new AlertDialog.Builder(this)
                            .setTitle("خطا في السيرفر")
                            .setMessage(String.valueOf(res))
                            .setCancelable(false)
                            .setPositiveButton("OK", null)
                            .show();
                }
            });
        });
    }

    private void showLoading() {
        if (loadingDialog != null && loadingDialog.isShowing()) return;

        View view = LayoutInflater.from(this).inflate(R.layout.animation_login, null);
        loadingDialog = new AlertDialog.Builder(this)
                .setView(view)
                .setCancelable(false)
                .create();

        if (loadingDialog.getWindow() != null) {
            loadingDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        loadingDialog.show();
    }

    private void hideLoading() {
        if (loadingDialog != null && loadingDialog.isShowing()) {
            loadingDialog.dismiss();
        }
        loadingDialog = null;
    }

    private void setLocale(String lang) {
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        android.content.res.Configuration config = new android.content.res.Configuration();
        config.locale = locale;
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }

    private static native String native_Check(Context context, String userKey);
}