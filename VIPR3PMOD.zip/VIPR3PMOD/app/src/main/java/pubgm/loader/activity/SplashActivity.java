package pubgm.loader.activity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;

import java.util.Locale;

import pubgm.loader.R;
import io.michaelrocks.paranoid.Obfuscate;
import pubgm.loader.utils.myTools;
import pubgm.loader.server.ApiServer;

@Obfuscate
public class SplashActivity extends androidx.appcompat.app.AppCompatActivity {
    myTools m = new myTools(this);
    public static boolean mahyong = false;
    Handler handler = new Handler();
    Runnable go;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mahyong = false;
        setContentView(R.layout.activity_splash);

        try {
            if (!ApiServer.verifyAppLabel(this)) {
                stopSplash();
                return;
            }
        } catch (Throwable ignored) {
            stopSplash();
            return;
        }

        if (blocked()) {
            stopSplash();
            return;
        }

        String currentLang = m.getSt("myKey", "mapLang", "en");
        setLocale(this, currentLang);

        TextView t = findViewById(R.id.tv_description);
        t.setSelected(true);

        LottieAnimationView l = findViewById(R.id.animationView);
        l.setAnimation(R.raw.anim_splash);
        l.playAnimation();

        go = () -> {
            if (!blocked()) {
                mahyong = true;
                startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                finish();
            }
        };

        handler.postDelayed(go, 4000);
    }

    private void stopSplash() {
        try { handler.removeCallbacks(go); } catch (Exception ignored) {}
        mahyong = false;
        finish();
    }

    private boolean blocked() {
        String[] p = {
                "com.guoshi.httpcanary.premium",
                "com.guoshi.httpcanary",
                "com.sniffer",
                "com.httpcanary.pro"
        };

        for (String x : p) {
            if (isAppInstalled(this, x)) return true;
        }
        return false;
    }

    private void setLocale(Context c, String lang) {
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Resources r = c.getResources();
        Configuration config = new Configuration(r.getConfiguration());
        config.setLocale(locale);
        c.createConfigurationContext(config);
        r.updateConfiguration(config, r.getDisplayMetrics());
        m.setSt("myKey", "mapLang", lang);
    }

    public static boolean isAppInstalled(Context c, String pkg) {
        try {
            c.getPackageManager().getPackageInfo(pkg, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
}