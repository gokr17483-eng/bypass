package pubgm.loader.activity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.blankj.molihuan.utilcode.util.ClipboardUtils;
import com.blankj.molihuan.utilcode.util.ToastUtils;
import pubgm.loader.R;
import pubgm.loader.databinding.ActivityCrashBinding;

import io.michaelrocks.paranoid.Obfuscate;

@Obfuscate
public class ZOONMODActivity extends AppCompatActivity {
    private ActivityCrashBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        );
        binding = ActivityCrashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.topAppBar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(getString(R.string.crash_log_title));
        }
        String error = getIntent().getStringExtra("Error");
        String software = getIntent().getStringExtra("Software");
        String date = getIntent().getStringExtra("Date");
        StringBuilder crashReport = new StringBuilder();
        if (software != null) crashReport.append(software).append("\n\n");
        if (error != null) crashReport.append(getString(R.string.stack_trace_label)).append("\n").append(error).append("\n\n");
        if (date != null) crashReport.append(getString(R.string.crash_date_label)).append("\n").append(date);
        binding.result.setText(crashReport.toString());
        binding.fab.setOnClickListener(v -> {
            ClipboardUtils.copyText(binding.result.getText());
            ToastUtils.make()
                    .setBgColor(Color.GRAY)
                    .setLeftIcon(R.drawable.ic_launcher_foreground)
                    .setNotUseSystemToast()
                    .setTextColor(Color.WHITE)
                    .show(getString(R.string.crash_log_copied));
        });
    }

    @Override
    public void onBackPressed() {
        finishAndRemoveTask();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem close = menu.add(getString(R.string.close_menu_item));
        close.setContentDescription(getString(R.string.close_app_description));
        close.setIcon(R.drawable.ic_close);
        close.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getTitle().equals(getString(R.string.close_menu_item))) {
            finishAndRemoveTask();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}