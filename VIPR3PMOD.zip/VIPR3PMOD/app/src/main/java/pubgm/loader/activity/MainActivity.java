package pubgm.loader.activity;

import android.content.res.Configuration;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import pubgm.loader.BoxApplication;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import top.niunaijun.blackbox.utils.FileUtils;
import android.graphics.Color;
import static pubgm.loader.server.ApiServer.activity;
import static pubgm.loader.server.ApiServer.EXP;
import static pubgm.loader.activity.LoginActivity.USERKEY;
import top.niunaijun.blackbox.BlackBoxCore;
import pubgm.loader.utils.UiKit;
import java.util.List;
import android.widget.ToggleButton;
import java.util.Locale;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.ColorDrawable;
import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.button.MaterialButton;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import com.blankj.molihuan.utilcode.util.SnackbarUtils;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import androidx.appcompat.app.AlertDialog;
import pubgm.loader.utils.PermissionUtils;
import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import pubgm.loader.R;
import pubgm.loader.floating.FloatService;
import pubgm.loader.floating.Overlay;
import pubgm.loader.floating.ToggleBullet;
import pubgm.loader.utils.FLog;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.topjohnwu.superuser.Shell;
import android.view.LayoutInflater;
import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import pubgm.loader.utils.ActivityCompat;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import androidx.appcompat.app.AlertDialog;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Set;
import static top.niunaijun.blackbox.core.env.BEnvironment.getDataFilesDir;
import top.niunaijun.blackbox.entity.pm.InstallResult;
import android.os.AsyncTask;
import java.util.TimeZone;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.os.Environment;
import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import android.view.Gravity;
import android.content.pm.PackageInfo;
import android.content.pm.Signature;
import java.security.MessageDigest;
import android.os.StatFs;
import pubgm.loader.animation.ParticleBackground;

public class MainActivity extends ActivityCompat {
    public static String socket;
    public static String daemonPath;
    public static boolean check = false;
    static MainActivity instance;
    private TextView bmode, safe_txt;
    public String verPath;
    static {
        System.loadLibrary("livai");
    }
    Context ctx;
    InstallResult installResult;
    BlackBoxCore blackboxCore;
    public static String TimeExpired;
    private static final int REQUEST_PERMISSIONS = 1;
    private static final String PREF_NAME = "espValue";
    private SharedPreferences sharedPreferences;
    String[] appPackage = {"com.tencent.ig", "com.pubg.krmobile", "com.rekoo.pubgm", "com.vng.pubgmobile", "com.twitter.android", "com.facebook.katana"};
    public String nameGame = "PROTECTION GLOBAL";
    public String CURRENT_PACKAGE = "";
    public LinearProgressIndicator progres;
    public CardView enable, disable;
    public static int gameint = 1;
    public static String bypassmode = "Automatic";
    public static int bitversi = 64;
    public static boolean noroot = false;
    public static int device = 1;
    public static String game = "com.tencent.ig";
    TextView root;
    public static boolean kernel = false;
    public static boolean Ischeck = false;
    public static boolean modestatus = false;
    public LinearLayout container;
    static boolean isLibLoaded = false;
    public static String modeselect;
    public static String typelogin;
    private boolean isLogin;
    private Handler timerHandler;
    private Runnable timerRunnable;
    private TextView Hari, Jam, Menit, Detik;
    private boolean isMenuVisible = false;
    private static boolean isFloatServiceRunning = false;

    public static MainActivity get() {
        return instance;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        blackboxCore = BlackBoxCore.get();
        blackboxCore.doCreate();
        setContentView(R.layout.activity_main);
        
        ParticleBackground particleBackground = new ParticleBackground(this);
        View rootView = findViewById(android.R.id.content);
        if (rootView instanceof ViewGroup) {
            ((ViewGroup) rootView).addView(particleBackground, 0);
        }
        
        Thread.setDefaultUncaughtExceptionHandler(new CrashHandler(this));

        init();
        if (savedInstanceState != null) {
            return;
        }
        
        ctx = this;
        devicecheck();
        instance = this;
        isLogin = true;
        makeDir();
        
        initButtons();
        setupGameCards();
        setupSocialCards();
        countTimerAccount();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Loadssets();
        }, 5000);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    public void devicecheck() {
        if (Shell.rootAccess()) {
            FLog.info(getString(R.string.root_granted));
            modeselect = String.format(getString(R.string.root_mode), Build.VERSION.RELEASE);
            Ischeck = true;
            noroot = true;
            device = 1;
        } else {
            FLog.info(getString(R.string.root_not_granted));
            modeselect = String.format(getString(R.string.non_root_mode), Build.VERSION.RELEASE);
            Ischeck = false;
            device = 2;
        }
    }

    @SuppressLint("SetTextI18n")
    private void initButtons() {
        MaterialButton delete_reports = findViewById(R.id.delete_reports);
        delete_reports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                File reportFile = new File(getFilesDir() + "/REPORT.sh");
                if (reportFile.exists()) {
                    Exec("/REPORT.sh", getString(R.string.reports_deleted_success));
                    Toast.makeText(MainActivity.this, getString(R.string.deleting_reports), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, getString(R.string.reports_delete_error), Toast.LENGTH_LONG).show();
                }
            }
        });

        final ToggleButton hide_recorder = findViewById(R.id.hide_recorder);
        hide_recorder.setChecked(getPref().readBoolean("anti_recorder"));
        hide_recorder.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                getPref().writeBoolean("anti_recorder", isChecked);
                SnackbarUtils.with(buttonView)
                        .setBgColor(R.color.ui)
                        .setMessage(getString(R.string.restart_required))
                        .setMessageColor(Color.WHITE)
                        .setAction(getString(R.string.ok_action), v -> {
                            restartApp(MainActivity.class.getSimpleName());
                        })
                        .show();
            }
        });

    }

    private void setupGameCards() {
        setupGameCard(R.id.globalIcon, R.id.globalStatus, R.id.globalInstallStatus, R.id.InstallGlobal, "com.tencent.ig", getString(R.string.global));
        setupGameCard(R.id.koreaIcon, R.id.koreaStatus, R.id.koreaInstallStatus, R.id.InstallKR, "com.pubg.krmobile", getString(R.string.korea));
        setupGameCard(R.id.taiwanIcon, R.id.taiwanStatus, R.id.taiwanInstallStatus, R.id.InstallTW, "com.rekoo.pubgm", getString(R.string.taiwan));
        setupGameCard(R.id.vietnamIcon, R.id.vietnamStatus, R.id.vietnamInstallStatus, R.id.InstallVNG, "com.vng.pubgmobile", getString(R.string.vietnam));
    }

    private void setupSocialCards() {
        setupGameCard(R.id.twitterIcon, R.id.twitterStatus, R.id.twitterInstallStatus, R.id.InstallTwitter, "com.twitter.android", getString(R.string.twitter));
        setupGameCard(R.id.facebookIcon, R.id.facebookStatus, R.id.facebookInstallStatus, R.id.InstallFacebook, "com.facebook.katana", getString(R.string.facebook));
    }

    private void setupGameCard(int iconId, int statusId, int installStatusId, int buttonId, final String packageName, String gameName) {
        TextView statusText = findViewById(statusId);
        TextView installStatusText = findViewById(installStatusId);
        MaterialButton installButton = findViewById(buttonId);
        CardView cardView = findParentCardView(installButton);

        updateCardStatus(packageName, installStatusText, installButton);

        installButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleCardInstallClick(packageName, installStatusText, installButton);
            }
        });

        if (cardView != null) {
            cardView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showDeleteAppDialog(packageName, gameName, installStatusText, installButton);
                    return true;
                }
            });
        }
    }

    private CardView findParentCardView(View view) {
        View parent = (View) view.getParent();
        while (parent != null && !(parent instanceof CardView)) {
            parent = (View) parent.getParent();
        }
        return (CardView) parent;
    }

    private void showDeleteAppDialog(final String packageName, String gameName, final TextView installStatusText, final MaterialButton installButton) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.delete_app));
        builder.setMessage(String.format(getString(R.string.delete_app_confirmation), gameName));

        builder.setPositiveButton(getString(R.string.delete), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteApp(packageName, installStatusText, installButton);
            }
        });

        builder.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.buttoon4));
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(getResources().getColor(R.color.buttoon4));
    }

    private void deleteApp(String packageName, TextView installStatusText, MaterialButton installButton) {
        if (blackboxCore.isInstalled(packageName, 0)) {
            try {
                stopAllServices();
                
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            blackboxCore.uninstallPackage(packageName);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(MainActivity.this, getString(R.string.app_deleted_success), Toast.LENGTH_SHORT).show();
                                    updateCardStatus(packageName, installStatusText, installButton);
                                    deleteObbFolder(packageName);
                                }
                            });
                        } catch (Exception e) {
                            e.printStackTrace();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(MainActivity.this, getString(R.string.app_delete_failed), Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                }, 1000);
                
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, getString(R.string.app_delete_failed), Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, getString(R.string.app_not_installed), Toast.LENGTH_SHORT).show();
        }
    }

    private void stopAllServices() {
        try {
            stopService(new Intent(MainActivity.get(), FloatService.class));
            stopService(new Intent(MainActivity.get(), Overlay.class));
            stopService(new Intent(MainActivity.get(), ToggleBullet.class));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean isAppInstalledOnDevice(String packageName) {
        try {
            PackageManager pm = getPackageManager();
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private void openPlayStore(String packageName) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("market://details?id=" + packageName));
            startActivity(intent);
        } catch (Exception e) {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=" + packageName));
            startActivity(intent);
        }
    }

    private void updateCardStatus(String packageName, TextView installStatusText, MaterialButton installButton) {
        boolean isInstalled = blackboxCore.isInstalled(packageName, 0);
        
        if (isInstalled) {
            installStatusText.setText(getString(R.string.installed));
            installButton.setText(getString(R.string.open));
        } else {
            installStatusText.setText(getString(R.string.not_installed));
            installButton.setText(getString(R.string.install));
        }
    }

    private void handleCardInstallClick(String packageName, TextView installStatusText, MaterialButton installButton) {
        if (blackboxCore.isInstalled(packageName, 0)) {
            blackboxCore.launchApk(packageName, 0);
            
            if (!isFloatServiceRunning) {
                startFloater();
            } else {
                sendBroadcast(new Intent("RESTART_FLOAT_SERVICE"));
            }
        } else {
            if (isAppInstalledOnDevice(packageName)) {
                blackboxCore.installPackageAsUser(packageName, 0);

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        updateCardStatus(packageName, installStatusText, installButton);
                        if (needsObbFile(packageName)) {
                            copyObbForPackage(packageName);
                        }
                    }
                }, 2000);
            } else {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(getString(R.string.app_not_installed_title));
                builder.setMessage(getString(R.string.app_not_installed_message));

                builder.setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        openPlayStore(packageName);
                    }
                });

                builder.setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();

                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(getResources().getColor(R.color.buttoon4));
                dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(getResources().getColor(R.color.buttoon4));
            }
        }
    }

    private boolean needsObbFile(String packageName) {
        String[] nonObbApps = {
            "com.twitter.android",
            "com.facebook.katana",
            "mark.via.gp"
        };
        
        for (String app : nonObbApps) {
            if (app.equals(packageName)) {
                return false;
            }
        }
        return true;
    }

    private boolean isObbFileAvailable(String packageName) {
        int versionCode = getVersionCodeForPackage(packageName);
        if (versionCode == 0) return false;

        File sourceObb = findObbFile(packageName, versionCode);
        if (sourceObb != null && sourceObb.exists()) {
            return true;
        }
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ignored) {}
        sourceObb = findObbFile(packageName, versionCode);
        return sourceObb != null && sourceObb.exists();
    }

    private void copyObbForPackage(String packageName) {
        int versionCode = getVersionCodeForPackage(packageName);
        if (versionCode == 0) {
            Toast.makeText(this, getString(R.string.unknown_version, packageName), Toast.LENGTH_LONG).show();
            return;
        }

        File sourceObb = findObbFile(packageName, versionCode);
        
        if (sourceObb == null || !sourceObb.exists()) {
            Toast.makeText(this, getString(R.string.obb_not_found, packageName), Toast.LENGTH_LONG).show();
            return;
        }

        File destDir = new File("/storage/emulated/0/blackbox/Android/obb/" + packageName + "/");
        if (!destDir.exists()) {
            if (!destDir.mkdirs()) {
                Toast.makeText(this, R.string.failed_create_dir, Toast.LENGTH_LONG).show();
                return;
            }
        }

        File destObb = new File(destDir, sourceObb.getName());

        if (destObb.exists()) {
            Toast.makeText(this, getString(R.string.obb_already_installed, packageName), Toast.LENGTH_LONG).show();
            return;
        }

        new MyCopyTask(packageName).execute(sourceObb.getAbsolutePath(), packageName);
    }

    private File findObbFile(String packageName, int versionCode) {
        String obbFileName = "main." + versionCode + "." + packageName + ".obb";

        String[] searchPaths = {
            "/storage/emulated/0/Android/obb/" + packageName,
            "/storage/emulated/0/obb/" + packageName,
            "/blackbox/Android/obb/" + packageName,
            "/blackbox/obb/" + packageName,
            Environment.getExternalStorageDirectory() + "/Android/obb/" + packageName,
            Environment.getExternalStorageDirectory() + "/obb/" + packageName
        };

        for (String path : searchPaths) {
            File obbFile = new File(path, obbFileName);
            if (obbFile.exists()) {
                return obbFile;
            }
        }

        return null;
    }

    private class MyCopyTask extends AsyncTask<String, Void, Boolean> {
        private String packageName;

        public MyCopyTask(String packageName) {
            this.packageName = packageName;
        }

        @Override
        protected Boolean doInBackground(String... params) {
            String sourcePath = params[0];
            File source = new File(sourcePath);
            File destDir = new File("/storage/emulated/0/blackbox/Android/obb/" + packageName + "/");
            File dest = new File(destDir, source.getName());

            try {
                FileInputStream inStream = new FileInputStream(source);
                FileOutputStream outStream = new FileOutputStream(dest);
                FileChannel inChannel = inStream.getChannel();
                FileChannel outChannel = outStream.getChannel();
                inChannel.transferTo(0, inChannel.size(), outChannel);
                inStream.close();
                outStream.close();
                return true;
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                Toast.makeText(MainActivity.this, getString(R.string.obb_copied_success), Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, getString(R.string.obb_copy_failed), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void deleteObbFolder(String packageName) {
        try {
            File obbFolder = new File("/storage/emulated/0/blackbox/Android/obb/" + packageName + "/");
            if (obbFolder.exists() && obbFolder.isDirectory()) {
                deleteRecursive(obbFolder);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void deleteRecursive(File fileOrDirectory) {
        try {
            if (fileOrDirectory.isDirectory()) {
                File[] children = fileOrDirectory.listFiles();
                if (children != null) {
                    for (File child : children) {
                        deleteRecursive(child);
                    }
                }
            }
            fileOrDirectory.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean checkStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    public void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            }, REQUEST_PERMISSIONS);
        }
    }

    private int getVersionCodeForPackage(String packageName) {
        try {
            PackageInfo pInfo = getPackageManager().getPackageInfo(packageName, 0);
            return pInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return 0;
        }
    }

    void gameversion(LinearLayout a, LinearLayout b, LinearLayout c, LinearLayout d, LinearLayout e){
        a.setBackgroundResource(R.drawable.bgfituron);
        b.setBackgroundResource(R.drawable.bgfituroff);
        c.setBackgroundResource(R.drawable.bgfituroff);
        d.setBackgroundResource(R.drawable.bgfituroff);
        e.setBackgroundResource(R.drawable.bgfituroff);
    }

    void init() {
    }

    void makeDir() {
        if (!Shell.rootAccess()) {
            File GlobalFolder = new File("/storage/emulated/0/blackbox/Android/obb/com.tencent.ig/");
            File KoreaFolder = new File("/storage/emulated/0/blackbox/Android/obb/com.pubg.krmobile/");
            if (!GlobalFolder.exists()) {
                GlobalFolder.mkdirs();
                KoreaFolder.mkdirs();
            }
        }
    }

    public void Exec(String path, String toast) {
        try {
            ExecuteElf("su -c chmod 777 " + getFilesDir() + path);
            ExecuteElf("su -c " + getFilesDir() + path);
            ExecuteElf("chmod 777 " + getFilesDir() + path);
            ExecuteElf(  getFilesDir() + path);
            Toast.makeText(this, toast, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
        }
    }

    private void ExecuteElf(String shell) {
        try {
            Runtime.getRuntime().exec(shell, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void excpp(String path) {
        try {
            ExecuteElf("chmod 777 " + getFilesDir() + path);
            ExecuteElf(getFilesDir() + path);
            ExecuteElf("su -c chmod 777 " + getFilesDir() + path);
            ExecuteElf("su -c " + getFilesDir() + path);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void Loadssets() {
        moveAssets(getFilesDir() + "/", "socs64");
        moveAssets(getFilesDir() + "/", "socu64");
        moveAssets(getFilesDir() + "/", "socs32");
        moveAssets(getFilesDir() + "/", "socu32");
        moveAssets(getFilesDir() + "/", "TW");
        moveAssets(getFilesDir() + "/", "VNG");
        moveAssets(getFilesDir() + "/", "logo");
        moveAssets(getFilesDir() + "/", "island");
        moveAssets(getFilesDir() + "/", "suck64");
        moveAssets(getFilesDir() + "/", "LIVAI");
        moveAssets(getFilesDir() + "/", "kernels64");
        moveAssets(getFilesDir() + "/", "REPORT.sh");
    }

    private boolean moveAssets(String outPath, String fileName) {
        File file = new File(outPath);
        if (!file.exists()) {
            if (!file.mkdirs()) {
                Log.e("--Method--", "copyAssetsSingleFile: cannot create directory.");
                return false;
            }
        }
        try {
            InputStream inputStream = getAssets().open(fileName);
            File outFile = new File(file, fileName);
            FileOutputStream fileOutputStream = new FileOutputStream(outFile);
            byte[] buffer = new byte[1024];
            int byteRead;
            while (-1 != (byteRead = inputStream.read(buffer))) {
                fileOutputStream.write(buffer, 0, byteRead);
            }
            inputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public String loadJSONFromAsset(String fileName) {
        String json = null;
        try {
            InputStream is = getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopAllServices();
        
        if (timerHandler != null && timerRunnable != null) {
            timerHandler.removeCallbacks(timerRunnable);
        }
        
        finishAffinity();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Toast.makeText(this, getString(R.string.please_click_icon_logout_for_exit), Toast.LENGTH_SHORT).show();
    }

    public LinearProgressIndicator getProgresBar() {
        return progres;
    }

    public void doShowProgress(boolean indeterminate) {
        if (progres == null) {
            return;
        }
        progres.setVisibility(View.VISIBLE);
        progres.setIndeterminate(indeterminate);

        if (!indeterminate) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                progres.setMin(0);
            }
            progres.setMax(100);
        }
    }

    public void doHideProgress() {
        if (progres == null) {
            return;
        }
        progres.setIndeterminate(true);
        progres.setVisibility(View.GONE);
    }

    private boolean isServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (manager != null) {
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (FloatService.class.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }
        }
        return false;
    }

    private void startPatcher() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(MainActivity.get())) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 123);
            } else {
                startFloater();
            }
        }
    }

    private void startFloater() {
        try {
            isFloatServiceRunning = true;
            startService(new Intent(MainActivity.get(), FloatService.class));
            loadAssets();
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!isServiceRunning()) {
                        try {
                            startService(new Intent(MainActivity.get(), FloatService.class));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }, 500);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void stopPatcher() {
        stopAllServices();
        isFloatServiceRunning = false;
    }

    public void loadAssets() {
        String filepath = Environment.getExternalStorageDirectory() + "/Android/data/.tyb";
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(filepath);
            byte[] buffer = "DO NOT DELETE".getBytes();
            fos.write(buffer, 0, buffer.length);
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        String sockver = "socu64";
        if (kernel) {
            if (bitversi == 64) {
                sockver = "kernels64";
            } else if (bitversi == 32) {
                sockver = "kernels32";
            }
        } else {
            if (bitversi == 64) {
                sockver = "socu64";
            } else if (bitversi == 32) {
                sockver = "socu32";
            }
        }

        daemonPath = getFilesDir().toString() + "/" + sockver;
        socket = daemonPath;
        try {
            Runtime.getRuntime().exec("chmod 777 " + daemonPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (timerHandler != null && timerRunnable != null) {
            timerHandler.postDelayed(timerRunnable, 0);
        }
        
        isFloatServiceRunning = isServiceRunning();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (timerHandler != null && timerRunnable != null) {
            timerHandler.removeCallbacks(timerRunnable);
        }
    }

    private void countTimerAccount() {
        Hari = findViewById(R.id.tv_d);
        Jam = findViewById(R.id.tv_h);
        Menit = findViewById(R.id.tv_m);
        Detik = findViewById(R.id.tv_s);

        timerHandler = new Handler();
        timerRunnable = new Runnable() {
            @Override
            public void run() {
                try {
                    TimeExpired = EXP();

                    if (TimeExpired == null || TimeExpired.isEmpty()) {
                        Hari.setText("00");
                        Jam.setText("00");
                        Menit.setText("00");
                        Detik.setText("00");

                        finishAffinity();
                        System.exit(0);
                        return;
                    }

                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                    Date expiryDate;
                    try {
                        expiryDate = dateFormat.parse(TimeExpired);
                    } catch (ParseException e) {
                        e.printStackTrace();
                        Hari.setText("00");
                        Jam.setText("00");
                        Menit.setText("00");
                        Detik.setText("00");

                        finishAffinity();
                        System.exit(0);
                        return;
                    }

                    long now = System.currentTimeMillis();
                    long distance = expiryDate.getTime() - now;

                    if (distance <= 0) {
                        Hari.setText("00");
                        Jam.setText("00");
                        Menit.setText("00");
                        Detik.setText("00");

                        finishAffinity();
                        System.exit(0);
                        return;
                    }

                    long days = distance / (24 * 60 * 60 * 1000);
                    long hours = (distance / (60 * 60 * 1000)) % 24;
                    long minutes = (distance / (60 * 1000)) % 60;
                    long seconds = (distance / 1000) % 60;

                    Hari.setText(String.format(Locale.getDefault(), "%02d", days));
                    Jam.setText(String.format(Locale.getDefault(), "%02d", hours));
                    Menit.setText(String.format(Locale.getDefault(), "%02d", minutes));
                    Detik.setText(String.format(Locale.getDefault(), "%02d", seconds));

                    timerHandler.postDelayed(this, 1000);
                } catch (Exception e) {
                    e.printStackTrace();
                    Hari.setText("00");
                    Jam.setText("00");
                    Menit.setText("00");
                    Detik.setText("00");

                    finishAffinity();
                    System.exit(0);
                }
            }
        };

        timerHandler.postDelayed(timerRunnable, 0);
    }
}