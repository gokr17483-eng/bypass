#ifndef BETA_ESP_IMPORTANT_HACKS_H
#define BETA_ESP_IMPORTANT_HACKS_H

#include "socket.h"
#include "Color.h"
#include "items.h"
#include "Vector3.hpp"
#include "timer.h"

timer FPSControl;

Color clrEnemy, clrEdge, clrBox, clrAlert, clr, clrTeam, clrDist, clrHealth, clrText, grenadeColor, clrtanda;
float h, w, x, y, z, magic_number, mx, my, top, bottom, textsize, mScale, skelSize;
Options options{1, -1, -1, 3, false, false, 1, false, 200, 200, 700, 19, 19, -1, false};
OtherFeature otherFeature{false, false, false, false, false};

int botCount, playerCount;
Response response;
Request request;
char extra[30];
char text[100];
int hCounter = 50;

Color colorByDistance(int distance, int alpha) {
    Color clrDistance;
    if (distance < 600)
        clrDistance = Color::Yellow(255);
    if (distance < 300)
        clrDistance = Color::Orange(255);
    if (distance < 150)
        clrDistance = Color::Red(255);
    return clrDistance;
}

bool isOutsideSafeR3P(Vec2 pos, Vec2 screen) {
    if (pos.y < 0) return true;
    if (pos.x > screen.x) return true;
    if (pos.y > screen.y) return true;
    return pos.x < 0;
}

std::string playerstatus(int GetEnemyState) {
    switch (GetEnemyState) {
        case 520:
        case 544:
        case 656:
        case 521:
        case 528:
        case 3145736:
            return "Aiming";
        default:
            return "";
    }
}

Vec2 calculatePosition(const Vec2 &center, float radius, float angleDegrees) {
    float angleRadians = angleDegrees * (M_PI / 180.0f);
    float x = center.x + radius * cos(angleRadians);
    float y = center.y + radius * sin(angleRadians);
    return Vec2(x, y);
}

bool colorPosCenter(float sWidth, float smMx, float sHeight, float posT, float eWidth, float emMx, float eHeight, float posB) {
    return sWidth >= smMx && sHeight >= posT && eWidth <= emMx && eHeight <= posB;
}

Vec2 pushToScreenBorder(const Vec2 &location, const Vec2 &screen, float offset, float scale = 2.0f) {
    Vec2 center(screen.x / 2, screen.y / 2);
    float angle = atan2(location.y - center.y, location.x - center.x) * (180.0f / M_PI);
    return calculatePosition(center, offset * scale, angle);
}

void DrawRadar(ESP canvas, Vec2 Location, Vec2 Pos, float Size, Color clr, int TeamID) {
    canvas.DrawFilledRoundRect(Color::White(255), {Pos.x - Size / 25, Pos.y - Size / 25}, {Pos.x + Size / 25, Pos.y + Size / 25});
    canvas.DrawFillCircle(Color(clr.r, clr.g, clr.b, 255), Location, Size / 10, 0.5);
    if (isPlayerName) {
        canvas.DrawText(Color::White(255), std::to_string(TeamID).c_str(), Location, Size / 10);
    }
}

void DrawESP(ESP esp, int screenWidth, int screenHeight) {
float topMargin = screenHeight / 25;
float textSizeTop = screenHeight / 35;
float leftMargin = (screenWidth / 15) + (screenWidth * 0.015f);



esp.DrawText(Color::White(255), "TG : @UC_00",
             Vec2(leftMargin, topMargin + textSizeTop * 2.6f), textSizeTop);
    
   esp.DrawTextMode(Color::White(255), "ANDROID", Vec2(screenWidth / 5, screenHeight / 1.05), screenHeight / 30);


    const char *statusText = "";
    if (options.aimBullet == 0) statusText = "الـبـولت تــرك";
    else if (otherFeature.Aimbot) statusText = "ايـمـبـوت";
    else if (otherFeature.LessRecoil || otherFeature.SmallCrosshair || otherFeature.WideView) statusText = "تـــفـــعـــيــلات";
    else statusText = "الـكـشـف";

    esp.DrawTexture(Color::Green(255), statusText, Vec2(screenWidth / 5, screenHeight / 1.09), screenHeight / 30);  

    request.ScreenHeight = screenHeight;  
    request.ScreenWidth = screenWidth;  
    request.options = options;  
    request.otherFeature = otherFeature;  
    request.Mode = InitMode;  

    botCount = 0; playerCount = 0;  
    send((void *)&request, sizeof(request));  
    receive((void *)&response);  
    mScale = screenHeight / 1080.0f;  
    skelSize = mScale * 1.5f;  
    float BoxSize = mScale * 2.0f;  
    textsize = screenHeight / 50;  
    Vec2 screen(screenWidth, screenHeight);  

    if (response.Success) {
        for (int i = 0; i < response.PlayerCount; i++) {
            PlayerData Player = response.Players[i];
            x = Player.HeadLocation.x;
            y = Player.HeadLocation.y;
            float magic_number = Player.Distance * response.fov;
            float namewidht = (screenWidth / 6) / magic_number;
            float pp2 = namewidht / 2;
            float mx = (screenWidth / 4) / magic_number;
            float my = (screenWidth / 1.38) / magic_number;
            float top = y - my + (screenWidth / 1.7) / magic_number;
            float bottom = Player.Bone.lAn.y + my - (screenWidth / 1.7) / magic_number;
            clrDist = colorByDistance((int)Player.Distance, 255);
            clrAlert = _clrID((int)Player.TeamID, 80);
            clrTeam = _clrID((int)Player.TeamID, 150);
            clr = _clrID((int)Player.TeamID, 200);
            Vec2 location(x, y);

            if (Player.isBot) {
                botCount++;
                clrEnemy = Color::White(255);
                clrEdge = Color::White(80);
                clrBox = Color::White(255);
                clrText = Color::Black(255);
            } else {
                playerCount++;
                clrEnemy = clrDist;
                clrEdge = clrAlert;
                clrBox = Color::Red(255);
                clrText = Color::White(255);
            }

            if (Player.HeadLocation.z != 1) {
                if (x > -50 && x < screenWidth + 50) {
                    if (isSkeleton && Player.Bone.isBone) {
                        float skelSize = mScale * 2.0f;
                    
                        Color clrSkeleton;
                        if (Player.isVisible) {
                            clrSkeleton = Color::Green(255);
                        } else {
                            clrSkeleton = Color::Red(255);
                        }
                    
                        esp.DrawLine(clrSkeleton, skelSize, Vec2(Player.Bone.neck.x, Player.Bone.neck.y), Vec2(Player.Bone.cheast.x, Player.Bone.cheast.y));
                        esp.DrawLine(clrSkeleton, skelSize, Vec2(Player.Bone.cheast.x, Player.Bone.cheast.y), Vec2(Player.Bone.pelvis.x, Player.Bone.pelvis.y));
                        esp.DrawLine(clrSkeleton, skelSize, Vec2(Player.Bone.neck.x, Player.Bone.neck.y), Vec2(Player.Bone.lSh.x, Player.Bone.lSh.y));
                        esp.DrawLine(clrSkeleton, skelSize, Vec2(Player.Bone.neck.x, Player.Bone.neck.y), Vec2(Player.Bone.rSh.x, Player.Bone.rSh.y));
                        esp.DrawLine(clrSkeleton, skelSize, Vec2(Player.Bone.lSh.x, Player.Bone.lSh.y), Vec2(Player.Bone.lElb.x, Player.Bone.lElb.y));
                        esp.DrawLine(clrSkeleton, skelSize, Vec2(Player.Bone.rSh.x, Player.Bone.rSh.y), Vec2(Player.Bone.rElb.x, Player.Bone.rElb.y));
                        esp.DrawLine(clrSkeleton, skelSize, Vec2(Player.Bone.lElb.x, Player.Bone.lElb.y), Vec2(Player.Bone.lWr.x, Player.Bone.lWr.y));
                        esp.DrawLine(clrSkeleton, skelSize, Vec2(Player.Bone.rElb.x, Player.Bone.rElb.y), Vec2(Player.Bone.rWr.x, Player.Bone.rWr.y));
                        esp.DrawLine(clrSkeleton, skelSize, Vec2(Player.Bone.pelvis.x, Player.Bone.pelvis.y), Vec2(Player.Bone.lTh.x, Player.Bone.lTh.y));
                        esp.DrawLine(clrSkeleton, skelSize, Vec2(Player.Bone.pelvis.x, Player.Bone.pelvis.y), Vec2(Player.Bone.rTh.x, Player.Bone.rTh.y));
                        esp.DrawLine(clrSkeleton, skelSize, Vec2(Player.Bone.lTh.x, Player.Bone.lTh.y), Vec2(Player.Bone.lKn.x, Player.Bone.lKn.y));
                        esp.DrawLine(clrSkeleton, skelSize, Vec2(Player.Bone.rTh.x, Player.Bone.rTh.y), Vec2(Player.Bone.rKn.x, Player.Bone.rKn.y));
                        esp.DrawLine(clrSkeleton, skelSize, Vec2(Player.Bone.lKn.x, Player.Bone.lKn.y), Vec2(Player.Bone.lAn.x, Player.Bone.lAn.y));
                        esp.DrawLine(clrSkeleton, skelSize, Vec2(Player.Bone.rKn.x, Player.Bone.rKn.y), Vec2(Player.Bone.rAn.x, Player.Bone.rAn.y));
                    }
                    
                    if (isPlayerBox) {
                        esp.DrawLine(clrBox, BoxSize, Vec2(x + pp2, top), Vec2(x + namewidht, top));
                        esp.DrawLine(clrBox, BoxSize, Vec2(x - pp2, top), Vec2(x - namewidht, top));
                        esp.DrawLine(clrBox, BoxSize, Vec2(x + namewidht, top), Vec2(x + namewidht, top + pp2));
                        esp.DrawLine(clrBox, BoxSize, Vec2(x - namewidht, top), Vec2(x - namewidht, top + pp2));
                        esp.DrawLine(clrBox, BoxSize, Vec2(x + pp2, bottom), Vec2(x + namewidht, bottom));
                        esp.DrawLine(clrBox, BoxSize, Vec2(x - pp2, bottom), Vec2(x - namewidht, bottom));
                        esp.DrawLine(clrBox, BoxSize, Vec2(x - namewidht, bottom), Vec2(x - namewidht, bottom - pp2));
                        esp.DrawLine(clrBox, BoxSize, Vec2(x + namewidht, bottom), Vec2(x + namewidht, bottom - pp2));
                    }

                    if (isPlayerLine) {
                        esp.DrawLine(clrBox, screenHeight / 500, Vec2(screenWidth / 2, screenHeight / 10.5), Vec2(x, top - screenHeight / 32));
                    }

                    if (isPlayerHealth) {
                        float healthLength = screenWidth / 24;
                        if (healthLength < mx) healthLength = mx;
                        if (Player.Health < 25) clrHealth = Color(255, 0, 0, 185);
                        else if (Player.Health < 50) clrHealth = Color(255, 204, 0, 185);
                        else if (Player.Health < 75) clrHealth = Color(255, 255, 0, 185);
                        else clrHealth = Color(34, 214, 97, 225);
                        if (Player.Health == 0)
                            esp.DrawText(Color(255, 0, 0), "Knock", Vec2(x, top - screenHeight / 200), textsize);
                        else {
                            esp.DrawFilledRect(clrHealth, Vec2(x - healthLength, top - screenHeight / 30), Vec2(x - healthLength + (2 * healthLength) * Player.Health / 100, top - screenHeight / 225));
                            esp.DrawRect(Color(0, 0, 0), screenHeight / 640, Vec2(x - healthLength, top - screenHeight / 30), Vec2(x + healthLength, top - screenHeight / 255));
                        }
                    }

                    if (isPlayerHead) {
                        esp.DrawFilledCircle(clrEdge, Vec2(Player.HeadLocation.x, Player.HeadLocation.y), screenHeight / 12 / magic_number);
                    }

                    if (isPlayerName) {
                        if (Player.isBot) sprintf(extra, "[BOT]"), esp.DrawText(Color(255, 255, 255), extra, Vec2(x, top - 12), textsize);
                        else esp.DrawName(Color().White(255), Player.PlayerNameByte, Player.TeamID, Vec2(Player.HeadLocation.x, top - 12), textsize);
                    }

                    if (isPlayerDistance) {
                        sprintf(extra, "%0.0f M", Player.Distance);
                        esp.DrawText(Color(247, 175, 63, 255), extra, Vec2(x, bottom + screenHeight / 45), textsize);
                    }

if (isPlayerWeapon && response.Players[i].Weapon.isWeapon) {
    esp.DrawWeapon(Color(0, 255, 255, 255),
                  response.Players[i].Weapon.id,
                  response.Players[i].Weapon.ammo,
                  response.Players[i].Weapon.ammo,
                  Vec2(x, top - screenHeight / 12),
                  screenHeight / 45);
}
                }
            }
        }
    }

    for (int i = 0; i < response.GrenadeCount; i++) {
        GrenadeData grenade = response.Grenade[i];
        if (!isGrenadeWarning || grenade.Location.z == 1.0f) continue;
        const char *grenadeTypeText;
        switch (grenade.type) {
            case 1: grenadeColor = Color::Red(255); grenadeTypeText = "قــنــبـلـة"; break;
            case 2: grenadeColor = Color::Orange(255); grenadeTypeText = "حــارـقه"; break;
            case 3: grenadeColor = Color::Yellow(255); grenadeTypeText = "فلاش"; break;
            default: grenadeColor = Color::White(255); grenadeTypeText = "اســـمــوك";
        }
        sprintf(extra, "%s (%.0f m)", grenadeTypeText, grenade.Distance);
        esp.DrawCircle(grenadeColor, Vec2(grenade.Location.x, grenade.Location.y), screenHeight / 60, 2.0f);
        esp.DrawText(grenadeColor, extra, Vec2(grenade.Location.x, grenade.Location.y - (screenHeight / 50)), screenHeight / 45);
        esp.DrawText(grenadeColor, "●", Vec2(grenade.Location.x, grenade.Location.y), screenHeight / 45);
    }

    if (isHideItem) {
        for (int i = 0; i < response.VehicleCount; i++) {
            VehicleData vehicle = response.Vehicles[i];
            if (vehicle.Location.z != 1.0f) esp.DrawVehicles(vehicle.VehicleName, vehicle.Distance, vehicle.Health, vehicle.Fuel, Vec2(vehicle.Location.x, vehicle.Location.y), screenHeight / 47);
        }
        for (int i = 0; i < response.ItemsCount; i++) {
            ItemData currentItem = response.Items[i];
            if (currentItem.Location.z != 1.0f) esp.DrawItems(currentItem.ItemName, currentItem.Distance, Vec2(currentItem.Location.x, currentItem.Location.y), screenHeight / 50);
        }
    }

if (botCount + playerCount > 0) {
        esp.DrawEnemyCount(Color(255, 175, 20),
                           Vec2(screenWidth / 2 - screenHeight / 9, screenHeight / 14.2f),
                           Vec2(screenWidth / 2 + screenHeight / 9, screenHeight / 9.3f));
        sprintf(extra, "%d", playerCount + botCount);
        esp.DrawText(Color(0, 0, 0), extra, Vec2(screenWidth / 2, screenHeight / 10),
                     screenHeight / 35);
    } else {
        esp.DrawEnemyCount(Color(91, 255, 79),
                           Vec2(screenWidth / 2 - screenHeight / 9, screenHeight / 14.2f),
                           Vec2(screenWidth / 2 + screenHeight / 9, screenHeight / 9.3f));
        esp.DrawText(Color(0, 0, 0), OBFUSCATE("CLEAR"), Vec2(screenWidth / 2, screenHeight / 10),
                     screenHeight / 35);
    }
    if (options.tracingStatus) {
        float py = screenHeight / 2;
        float px = screenWidth / 2;
        esp.DrawFilledRect(Color::Green(50), Vec2(options.touchY - options.touchSize / 2, py *2 - options.touchX + options.touchSize / 2),
                          Vec2(options.touchY + options.touchSize / 2, py * 2 - options.touchX - options.touchSize / 2));
    }

    if (options.openState == 0 || options.aimBullet == 0 || options.aimT == 0) {
        const Color textColor = (options.openState == 0) ? Color::Red(255) : (options.aimT == 0 ? Color::Blue(255) : Color::Green(255));
        esp.DrawCircle(textColor, Vec2(screenWidth / 2, screenHeight / 2), options.aimingRange, 1.5);
    }

    FPSControl.SetFps(1000);
    FPSControl.AotuFPS();
}

#endif