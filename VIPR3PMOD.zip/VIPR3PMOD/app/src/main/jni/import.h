#ifndef R3PMOD_PRO_IMPORTANT_IMPORT_H
#define R3PMOD_PRO_IMPORTANT_IMPORT_H

#include <jni.h>
#include <string>
#include <cstdlib>
#include <unistd.h>
#include <sys/mman.h>
#include <android/log.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <cerrno>
#include <sys/un.h>
#include <cstring>
#include <string>
#include <cmath>
#include "struct.h"

bool isHideItem = true;
bool is360Alertv2 = true;
bool isSkeleton = true;
bool isPlayerHead = true;
bool isPlayerBox = true;
bool isLootBox = true;
bool isPlayerLine = true;
bool isPlayerHealth = true;
bool isPlayerName = true;
bool isPlayerDistance = true;
bool isPlayerWeapon = true;
bool isPlayerWeaponIcon = true;
bool isGrenadeWarning = true;
bool isPlayerUID = true;
bool isPlayerNation = true;
bool isPlayerTeamID = true;

int size(char *ptr) {
    int offset = 0;
    int count = 0;
    while (*(ptr + offset) != '\0') {
        ++count;
        ++offset;
    }
    return count;
}

#endif