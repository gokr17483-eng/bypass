// Login.h
#ifndef LOGIN_H
#define LOGIN_H

#include <jni.h>
#include <string>
#include <ctime>
#include <android/log.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/err.h>
#include <openssl/md5.h>
#include <curl/curl.h>
#include "json.hpp"
#include "StrEnc.h"
#include "Includes.h"
#include <fstream>

using json = nlohmann::ordered_json;

static bool bValid = false;
static bool xEnv = false;
static std::string g_Auth, g_Token, EXP;

static bool VIP() {
//  echo -n "https://SOLO1.x10.mx/connect" | md5sum
    std::string current_url = OBFUSCATE("https://SOLO1.x10.mx/connect");
    std::string expected_hash = (OBFUSCATE("34833ee789947624925015142322e59d"));
    
    unsigned char hash[MD5_DIGEST_LENGTH];
    MD5_CTX ctx;
    MD5_Init(&ctx);
    MD5_Update(&ctx, current_url.data(), current_url.size());
    MD5_Final(hash, &ctx);
    
    char hash_str[33];
    for(int i = 0; i < MD5_DIGEST_LENGTH; i++) {
        sprintf(&hash_str[i*2], "%02x", hash[i]);
    }
    hash_str[32] = 0;
    
    return (std::string(hash_str) == expected_hash);
}

static std::string GetAndroidID(JNIEnv *env, jobject context) {
    std::string result = "";
    jclass contextClass = nullptr;
    jclass secureClass = nullptr;
    
    try {
        contextClass = env->FindClass(OBFUSCATE("android/content/Context"));
        if (!contextClass) return result;
        
        jmethodID getContentResolverMethod = 
            env->GetMethodID(contextClass, OBFUSCATE("getContentResolver"),
                           OBFUSCATE("()Landroid/content/ContentResolver;"));
        if (!getContentResolverMethod) {
            env->DeleteLocalRef(contextClass);
            return result;
        }
        
        secureClass = env->FindClass(OBFUSCATE("android/provider/Settings$Secure"));
        if (!secureClass) {
            env->DeleteLocalRef(contextClass);
            return result;
        }
        
        jmethodID getStringMethod = 
            env->GetStaticMethodID(secureClass, OBFUSCATE("getString"),
                                 OBFUSCATE("(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;"));
        if (!getStringMethod) {
            env->DeleteLocalRef(contextClass);
            env->DeleteLocalRef(secureClass);
            return result;
        }
        
        jobject resolver = env->CallObjectMethod(context, getContentResolverMethod);
        if (!resolver) {
            env->DeleteLocalRef(contextClass);
            env->DeleteLocalRef(secureClass);
            return result;
        }
        
        jstring key = env->NewStringUTF(OBFUSCATE("android_id"));
        jstring jstr = (jstring)env->CallStaticObjectMethod(secureClass, getStringMethod, resolver, key);
        
        if (jstr) {
            const char *cstr = env->GetStringUTFChars(jstr, nullptr);
            if (cstr) {
                result = cstr;
                env->ReleaseStringUTFChars(jstr, cstr);
            }
            env->DeleteLocalRef(jstr);
        }
        
        env->DeleteLocalRef(key);
        env->DeleteLocalRef(resolver);
        
    } catch (...) {
    }
    
    if (contextClass) env->DeleteLocalRef(contextClass);
    if (secureClass) env->DeleteLocalRef(secureClass);
    
    return result;
}

static std::string GetDeviceModel(JNIEnv *env) {
    std::string result = "";
    jclass buildClass = nullptr;
    
    try {
        buildClass = env->FindClass(OBFUSCATE("android/os/Build"));
        if (!buildClass) return result;
        
        jfieldID field = env->GetStaticFieldID(buildClass, OBFUSCATE("MODEL"), OBFUSCATE("Ljava/lang/String;"));
        if (!field) {
            env->DeleteLocalRef(buildClass);
            return result;
        }
        
        jstring jstr = (jstring)env->GetStaticObjectField(buildClass, field);
        if (jstr) {
            const char *cstr = env->GetStringUTFChars(jstr, nullptr);
            if (cstr) {
                result = cstr;
                env->ReleaseStringUTFChars(jstr, cstr);
            }
            env->DeleteLocalRef(jstr);
        }
        
    } catch (...) {
    }
    
    if (buildClass) env->DeleteLocalRef(buildClass);
    return result;
}

static std::string GetDeviceBrand(JNIEnv *env) {
    std::string result = "";
    jclass buildClass = nullptr;
    
    try {
        buildClass = env->FindClass(OBFUSCATE("android/os/Build"));
        if (!buildClass) return result;
        
        jfieldID field = env->GetStaticFieldID(buildClass, OBFUSCATE("BRAND"), OBFUSCATE("Ljava/lang/String;"));
        if (!field) {
            env->DeleteLocalRef(buildClass);
            return result;
        }
        
        jstring jstr = (jstring)env->GetStaticObjectField(buildClass, field);
        if (jstr) {
            const char *cstr = env->GetStringUTFChars(jstr, nullptr);
            if (cstr) {
                result = cstr;
                env->ReleaseStringUTFChars(jstr, cstr);
            }
            env->DeleteLocalRef(jstr);
        }
        
    } catch (...) {
    }
    
    if (buildClass) env->DeleteLocalRef(buildClass);
    return result;
}

static std::string GetDeviceUniqueIdentifier(JNIEnv *env, const char *seed) {
    std::string result = "";
    jclass uuidClass = nullptr;
    
    try {
        uuidClass = env->FindClass(OBFUSCATE("java/util/UUID"));
        if (!uuidClass) return "";
        
        jmethodID fromBytes = 
            env->GetStaticMethodID(uuidClass, OBFUSCATE("nameUUIDFromBytes"),
                                 OBFUSCATE("([B)Ljava/util/UUID;"));
        if (!fromBytes) {
            env->DeleteLocalRef(uuidClass);
            return "";
        }
        
        jmethodID toString = 
            env->GetMethodID(uuidClass, OBFUSCATE("toString"), OBFUSCATE("()Ljava/lang/String;"));
        if (!toString) {
            env->DeleteLocalRef(uuidClass);
            return "";
        }
        
        jsize len = seed ? (jsize)strlen(seed) : 0;
        jbyteArray arr = env->NewByteArray(len);
        if (seed && arr) {
            env->SetByteArrayRegion(arr, 0, len, (const jbyte *)seed);
        }
        
        if (!arr) {
            env->DeleteLocalRef(uuidClass);
            return "";
        }
        
        jobject uuidObj = env->CallStaticObjectMethod(uuidClass, fromBytes, arr);
        if (!uuidObj) {
            env->DeleteLocalRef(arr);
            env->DeleteLocalRef(uuidClass);
            return "";
        }
        
        jstring jstr = (jstring)env->CallObjectMethod(uuidObj, toString);
        if (jstr) {
            const char *cstr = env->GetStringUTFChars(jstr, nullptr);
            if (cstr) {
                result = cstr;
                env->ReleaseStringUTFChars(jstr, cstr);
            }
            env->DeleteLocalRef(jstr);
        }
        
        env->DeleteLocalRef(uuidObj);
        env->DeleteLocalRef(arr);
        
    } catch (...) {
    }
    
    if (uuidClass) env->DeleteLocalRef(uuidClass);
    return result;
}

struct MemoryStruct {
    char *memory = nullptr;
    size_t size = 0;
};

static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t realsize = size * nmemb;
    MemoryStruct *mem = (MemoryStruct *)userp;

    char *ptr = (char *)realloc(mem->memory, mem->size + realsize + 1);
    if (!ptr) return 0;

    mem->memory = ptr;
    memcpy(mem->memory + mem->size, contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = '\0';
    return realsize;
}

static std::string CalcMD5(const std::string &s) {
    unsigned char hash[MD5_DIGEST_LENGTH];
    MD5_CTX ctx;
    MD5_Init(&ctx);
    MD5_Update(&ctx, s.data(), s.size());
    MD5_Final(hash, &ctx);

    char buf[3];
    std::string out;
    out.reserve(MD5_DIGEST_LENGTH * 2);
    for (int i = 0; i < MD5_DIGEST_LENGTH; ++i) {
        snprintf(buf, sizeof(buf), OBFUSCATE("%02x"), hash[i]);
        out.append(buf);
    }
    return out;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_pubgm_loader_activity_LoginActivity_native_1Check(JNIEnv *env, jclass clazz, jobject mContext, jstring mUserKey) {
    if (!env || !mContext) {
        return env->NewStringUTF(OBFUSCATE("Initialization error"));
    }
    
    if (!VIP()) {
        return env->NewStringUTF(OBFUSCATE("برجاء تحميل التطبيق الاصلي"));
    }
    
    const char *user_key = env->GetStringUTFChars(mUserKey, nullptr);
    if (!user_key) {
        return env->NewStringUTF(OBFUSCATE("Invalid user key"));
    }
    
    std::string errMsg;
    MemoryStruct chunk{};
    
    bValid = false;
    xEnv = false;
    g_Auth.clear();
    g_Token.clear();
    EXP.clear();
    
    std::string androidId = GetAndroidID(env, mContext);
    std::string model = GetDeviceModel(env);
    std::string brand = GetDeviceBrand(env);
    
    std::string hwid = std::string(user_key) + androidId + model + brand;
    std::string UUID = GetDeviceUniqueIdentifier(env, hwid.c_str());
    
    if (UUID.empty()) {
        env->ReleaseStringUTFChars(mUserKey, user_key);
        return env->NewStringUTF(OBFUSCATE("Device identification failed"));
    }
    
    curl_global_init(CURL_GLOBAL_DEFAULT);
    CURL *curl = curl_easy_init();
    if (!curl) {
        env->ReleaseStringUTFChars(mUserKey, user_key);
        return env->NewStringUTF(OBFUSCATE("Network error"));
    }
    
    std::string server_url = OBFUSCATE("https://SOLO1.x10.mx/connect");
    curl_easy_setopt(curl, CURLOPT_URL, server_url.c_str());
   // curl_easy_setopt(curl, CURLOPT_PINNEDPUBLICKEY, OBFUSCATE("sha256//e7T2r6dLdndApAy10ha3LEvO2DUNn7YCJl7KoocQ5ZA="));
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &chunk);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30L);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 15L);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    
    struct curl_slist *headers = nullptr;
    headers = curl_slist_append(headers, OBFUSCATE("Accept: application/json"));
    headers = curl_slist_append(headers, OBFUSCATE("Content-Type: application/x-www-form-urlencoded"));
    headers = curl_slist_append(headers, OBFUSCATE("Charset: UTF-8"));
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    
    char post_data[1024];
    snprintf(post_data, sizeof(post_data),
             OBFUSCATE("game=VIP&user_key=%s&serial=%s"),
             user_key, UUID.c_str());
    
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_data);
    
    CURLcode res = curl_easy_perform(curl);
    
    if (res == CURLE_OK && chunk.memory) {
        try {
            json result = json::parse(chunk.memory);
            if (result[OBFUSCATE("status")] == true) {
                g_Token = result[OBFUSCATE("data")][OBFUSCATE("token")].get<std::string>();
                EXP = result[OBFUSCATE("data")][OBFUSCATE("EXP")].get<std::string>();
                time_t rng = result[OBFUSCATE("data")][OBFUSCATE("rng")].get<time_t>();
                if (rng + 30 > time(nullptr)) {
                    std::string auth = OBFUSCATE("VIP-");
                    auth += user_key;
                    auth += OBFUSCATE("-");
                    auth += UUID;
                    auth += OBFUSCATE("-Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E");
                    g_Auth = CalcMD5(auth);
                    bValid = (g_Token == g_Auth);
                    xEnv = true;
                } else {
                    errMsg = OBFUSCATE("Session expired");
                }
            } else {
                errMsg = result[OBFUSCATE("reason")].get<std::string>();
            }
        } catch (...) {
            errMsg = OBFUSCATE("Server error");
        }
    } else {
        errMsg = OBFUSCATE("Connection failed");
    }
    
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    curl_global_cleanup();
    
    if (chunk.memory) {
        free(chunk.memory);
    }
    
    env->ReleaseStringUTFChars(mUserKey, user_key);
    
    return env->NewStringUTF(bValid ? OBFUSCATE("OK") : errMsg.c_str());
}

#endif